# StudentManagement
This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.0.5.

## Description
Программное средство учёта расчётов со студентами-стипендиатами в учреждениях высшего образования.
